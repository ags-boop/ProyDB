using System;
using System.ComponentModel.DataAnnotations;


namespace ProyectoParcial.Models
{
    public class FamiliaAdopcion
    {
        [Required]
        public int DNI {get;set;}
        [Required]
       public string NombreFamilia{get;set;}

        [Required]
       public int Telefono {get;set;}

        [Required]
       public string Casa {get;set;}

        [Required]
       public int PersonasConviven {get;set;}

        



    }
}
