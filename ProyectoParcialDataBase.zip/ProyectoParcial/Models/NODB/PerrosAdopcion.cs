using System;
using System.ComponentModel.DataAnnotations;


namespace ProyectoParcial.Models
{
    public class PerroAdopcion
    {
        [Required] [Range(0,99)]
       public int ID {get;set;}
        [Required]
       public string NombrePerro{get;set;}
       
       [Required]
       public string Sexo {get;set;}

        [MaxLength(30)]
       public string Raza{get;set;}

        [Range(1,20)]
       public int Edad {get;set;}

        [Required]
       public string Vacunas {get;set;}

       public int AnioResatado {get;set;}




    }
}
