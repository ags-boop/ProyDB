using System;

namespace ProyectoParcial.Models
{
    public class Sexo
    {
        public int ID { get; set; }

        public string SexoElegir {get;set;}
    }
}
