﻿using System;
using System.Collections.Generic;

namespace ProyectoParcial.Models
{
    public partial class PerroFamiliaDb
    {
        public int Idperro { get; set; }
        public int Dnifamilia { get; set; }
    }
}
