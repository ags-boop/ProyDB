﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;


namespace ProyectoParcial.Models
{
    public partial class PerroAdopcionDb
    {
        [Required] [Range(0,99)]
        public int Id { get; set; }
        [Required]
        public string NombrePerro { get; set; }
        [Required]
        public string Sexo { get; set; }
        [MaxLength(30)]
        public string Raza { get; set; }
        [Range(1,20)]
        public int? Edad { get; set; }
        [Required]
        public string Vacunas { get; set; }
        [Required]
        public string AnioRescatado { get; set; }
        public string FotoRuta {get;set;}
        [NotMapped()]
        public IFormFile Foto{get;set;}

    }
}
