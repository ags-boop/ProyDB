﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ProyectoParcial.Models
{
    public partial class PerrosAdopcionDbContext : DbContext
    {
        public PerrosAdopcionDbContext()
        {
        }

        public PerrosAdopcionDbContext(DbContextOptions<PerrosAdopcionDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<FamiliaAdopcionDb> FamiliaAdopcionDb { get; set; }
        public virtual DbSet<PerroAdopcionDb> PerroAdopcionDb { get; set; }
        public virtual DbSet<PerroFamiliaDb> PerroFamiliaDb { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                // optionsBuilder.UseSqlServer("Server=DESKTOP-8Q85QCQ;Database=PerrosAdopcion;trusted_connection=true; ");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FamiliaAdopcionDb>(entity =>
            {
                entity.HasKey(e => e.Dni)
                    .HasName("PK__FamiliaA__C035B8DC7C8A8EBF");

                entity.ToTable("FamiliaAdopcionDB");

                entity.Property(e => e.Dni)
                    .HasColumnName("DNI")
                    .ValueGeneratedNever();

                entity.Property(e => e.Casa)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NombreFamilia)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PerroAdopcionDb>(entity =>
            {
                entity.ToTable("PerroAdopcionDB");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AnioRescatado)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NombrePerro)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Raza)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Vacunas)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PerroFamiliaDb>(entity =>
            {
                entity.HasKey(e => new { e.Idperro, e.Dnifamilia })
                    .HasName("PK__PerroFam__B312E3CC35A740ED");

                entity.ToTable("PerroFamiliaDB");

                entity.Property(e => e.Idperro).HasColumnName("IDPerro");

                entity.Property(e => e.Dnifamilia).HasColumnName("DNIFamilia");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
