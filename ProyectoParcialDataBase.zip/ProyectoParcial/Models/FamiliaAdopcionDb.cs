﻿using System;
using System.Collections.Generic;

namespace ProyectoParcial.Models
{
    public partial class FamiliaAdopcionDb
    {
        public int Dni { get; set; }
        public string NombreFamilia { get; set; }
        public int Telefono { get; set; }
        public string Casa { get; set; }
        public int PersonasConviven { get; set; }
    }
}
