﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ProyectoParcial.Models;
using Microsoft.EntityFrameworkCore;
namespace ProyectoParcial.Controllers
{
    public class FamiliaAdopcionController : Controller
    {

        private readonly PerrosAdopcionDbContext _context;

        public FamiliaAdopcionController(PerrosAdopcionDbContext context)
        {
            _context = context;
        }
        public IActionResult Index(string campobusquedad)
        {
            var FamiliaDB = _context.FamiliaAdopcionDb
            .Select(p => new FamiliaAdopcionDb()
            {
                Dni = p.Dni,
                NombreFamilia = p.NombreFamilia,
                Casa = p.Casa,
                Telefono = p.Telefono,
                PersonasConviven = p.PersonasConviven,

            })
            .ToList();

             var busqueda = from s in _context.FamiliaAdopcionDb select s;

            if (!String.IsNullOrEmpty(campobusquedad))
            {
                busqueda = busqueda.Where(s => s.NombreFamilia.Contains(campobusquedad));
                return View(busqueda.ToList());
            }
            return View(FamiliaDB);
        }

        public IActionResult Order(string campobusquedad)
        {
            var busqueda = from s in _context.FamiliaAdopcionDb select s;

            if (!String.IsNullOrEmpty(campobusquedad))
            {
                busqueda = busqueda.Where(s => s.NombreFamilia.Contains(campobusquedad));
                return View(busqueda.ToList());
            }

            var FamiDB = _context.FamiliaAdopcionDb.OrderByDescending(c => c.Dni).ToList();
            return View(FamiDB);
        }

        public IActionResult Editar(int DNI)
        {
            var FamiliaDB = _context.FamiliaAdopcionDb.Where(x => x.Dni == DNI).FirstOrDefault();
            return View(FamiliaDB);
        }

        [HttpPost]

        public IActionResult Editar(FamiliaAdopcionDb fami, IFormCollection FamilyFor)
        {
            if (ModelState.IsValid)
            {
                _context.FamiliaAdopcionDb.Update(fami);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(fami);


        }

        public IActionResult Crear()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Crear(FamiliaAdopcionDb fami)
        {
            if (ModelState.IsValid)
            {
                var PerroDB = _context.FamiliaAdopcionDb.Where(s => s.Dni == fami.Dni).FirstOrDefault();
                if (PerroDB != null)
                { return View("Error"); }
                else
                {
                    _context.FamiliaAdopcionDb.Add(fami);
                    _context.SaveChanges();
                    return RedirectToAction("Index");

                }

            }
            return View(fami);


        }

        public IActionResult Detalle(int dni)
        {
            var FamiliaDB = _context.FamiliaAdopcionDb
             .Where(a => a.Dni == dni)
             .FirstOrDefault();
            return View(FamiliaDB);
        }

      [HttpPost, ActionName("Borrar")]
        public IActionResult Borrar(int dni)
        {

            FamiliaAdopcionDb Delete = new FamiliaAdopcionDb {Dni = dni }; 
            _context.Remove(Delete).State = EntityState.Deleted;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
         public IActionResult Error(){
            return View();
        }


    }
}
