﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ProyectoParcial.Models;
using X.PagedList;
using X.PagedList.Mvc.Core;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Web;
using Microsoft.AspNetCore.Hosting;

namespace ProyectoParcial.Controllers
{
    public class PerrosAdopcionController : Controller
    {

        private readonly PerrosAdopcionDbContext _context;
        private readonly IWebHostEnvironment _hostingEnvironment;

        public PerrosAdopcionController(PerrosAdopcionDbContext context, IWebHostEnvironment HostingEnvironment)
        {
            _context = context;
            _hostingEnvironment = HostingEnvironment;

        }


        public List<Sexo> SexoMenuDes = new List<Sexo>(){
            new Sexo(){ID=1,SexoElegir="M"},
            new Sexo(){ID=2,SexoElegir="H"},
        };

        public IActionResult Index(string campobusquedad)
        {
            var PerrosDb = _context.PerroAdopcionDb
             .Select(p => new PerroAdopcionDb()
             {
                 Id = p.Id,
                 NombrePerro = p.NombrePerro,
                 Sexo = (p.Sexo == null) ? "?" : p.Sexo,
                 Raza = p.Raza,
                 Edad = p.Edad,
                 Vacunas = p.Vacunas,
                 AnioRescatado = p.AnioRescatado,
                 FotoRuta = p.FotoRuta == null ? "generica.jpg" : p.FotoRuta
             })
             .ToList();


            var busqueda = from s in _context.PerroAdopcionDb select s;

            if (!String.IsNullOrEmpty(campobusquedad))
            {
                busqueda = busqueda.Where(s => s.NombrePerro.Contains(campobusquedad)
                                       || s.Raza.Contains(campobusquedad));
                return View(busqueda.ToList());
            }
            return View(PerrosDb);


        }

        public IActionResult Order(string campobusquedad)
        {
            var busqueda = from s in _context.PerroAdopcionDb select s;

            if (!String.IsNullOrEmpty(campobusquedad))
            {
                busqueda = busqueda.Where(s => s.NombrePerro.Contains(campobusquedad)
                                       || s.Raza.Contains(campobusquedad));
                return View(busqueda.ToList());
            }
            var PerroDB = _context.PerroAdopcionDb.OrderByDescending(c => c.Id).ToList();
            return View(PerroDB);
        }

        public IActionResult Editar(int id)
        {
            ViewBag.SexoMenuDes = SexoMenuDes;
            var PerroDB = _context.PerroAdopcionDb.Where(x => x.Id == id).FirstOrDefault();
            return View(PerroDB);
        }

        [HttpPost]

        public IActionResult Editar(PerroAdopcionDb Perro, IFormCollection PerroFor)
        {
            if (ModelState.IsValid)
            {
                string carpetaFotos = Path.Combine(_hostingEnvironment.WebRootPath, "ImagenesPerros");
                string nombreArchivo = Perro.Foto.FileName;
                string rutaCompleta = Path.Combine(carpetaFotos, nombreArchivo);
                //Img al servidor
                Perro.Foto.CopyTo(new FileStream(rutaCompleta, FileMode.Create));
                //Guardamos la ruta de la img
                Perro.FotoRuta = nombreArchivo;
                _context.PerroAdopcionDb.Update(Perro);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.SexoMenuDes = SexoMenuDes;

            return View(Perro);

        }

        public IActionResult Crear()
        {
            ViewBag.SexoMenuDes = SexoMenuDes;

            return View();
        }

        [HttpPost]
        public IActionResult Crear(PerroAdopcionDb PerroF)
        {

            if (ModelState.IsValid)
            {
                if (PerroF.Foto != null)
                {
                    string carpetaFotos = Path.Combine(_hostingEnvironment.WebRootPath, "ImagenesPerros");
                    string nombreArchivo = PerroF.Foto.FileName;
                    string rutaCompleta = Path.Combine(carpetaFotos, nombreArchivo);
                    //Img al servidor
                    PerroF.Foto.CopyTo(new FileStream(rutaCompleta, FileMode.Create));
                    //Guardamos la ruta de la img
                    PerroF.FotoRuta = nombreArchivo;
                }

                PerroF.Id = _context.PerroAdopcionDb.Max(X => X.Id + 1);
                _context.PerroAdopcionDb.Add(PerroF);
                _context.SaveChanges();
                return RedirectToAction("Index");


            }
            return View(PerroF);




        }
        public IActionResult Error()
        {
            return View();
        }

        public IActionResult Detalle(int id)
        {
            var PerroDB = _context.PerroAdopcionDb
             .Where(a => a.Id == id)
             .FirstOrDefault();
            return View(PerroDB);
        }


        [HttpPost, ActionName("Borrar")]
        public IActionResult Borrar(int id)
        {

            PerroAdopcionDb Delete = new PerroAdopcionDb { Id = id }; //Con numero harcodeado borra
            _context.Remove(Delete).State = EntityState.Deleted;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        private IPagedList Paginar(List<PerroAdopcionDb> ListaPerros, int? pagina)
        {
            int tamanioPag = 6;
            int numeroPagina = (pagina ?? 1);
            return ListaPerros.ToPagedList(numeroPagina, tamanioPag);
        }

        public IActionResult Listado(int? pagina)
        {
            return View(Paginar(_context.PerroAdopcionDb.ToList(), pagina));
        }




    }
}
